//package com.xh.es.dao;
//
//import com.xh.es.model.UserEntity;
//import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
///**
// * @author H.Yang
// * @date 2022/11/22
// */
//@Repository
//public interface UserDao extends ElasticsearchRepository<UserEntity, String> {
//
//    List<UserEntity> getByUsername(String username);
//}
