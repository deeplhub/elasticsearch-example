package com.xh.es.model.dto;

import lombok.Data;

/**
 * @description:
 * @author: black tea
 * @date: 2021/9/7 10:12
 */
@Data
public class PageRequest {

    public int page;

    public int limit;

}
